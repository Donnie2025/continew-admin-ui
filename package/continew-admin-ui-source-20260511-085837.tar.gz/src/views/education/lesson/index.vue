<template>
  <div class="gi_table_page">
    <GiTable
      title="课堂管理"
      row-key="id"
      :data="dataList"
      :columns="columns"
      :loading="loading"
      :scroll="{ x: '100%', y: '100%', minWidth: 1000 }"
      :pagination="pagination"
      :disabled-tools="['size']"
      :disabled-column-keys="['name']"
      @refresh="search"
    >
      <template #toolbar-left>
	    <a-input-search v-model="queryForm.name" placeholder="请输入课堂活动名称" allow-clear @search="search" @keyup.enter="search" />
	    <a-input-search v-model="queryForm.agentCode" placeholder="请输入代理机构编码" allow-clear @search="search" @keyup.enter="search" />
	    <a-select v-model="queryForm.courseStatus" placeholder="课程状态" allow-clear style="width: 120px" @change="search">
	      <a-option value="started">已开课</a-option>
	      <a-option value="not_started">未开课</a-option>
	    </a-select>
        <a-button @click="reset">
          <template #icon><icon-refresh /></template>
          <template #default>重置</template>
        </a-button>
      </template>
      <template #recordState="{ record }">
        <GiCellTag :value="record.recordState" :dict="yes_no" />
      </template>
      <template #liveState="{ record }">
        <GiCellTag :value="record.liveState" :dict="yes_no" />
      </template>
      <template #openState="{ record }">
        <GiCellTag :value="record.openState" :dict="yes_no" />
      </template>
      <template #agentCode="{ record }">
        <span>{{ record.agentCode || '-' }}</span>
      </template>
      <template #remark="{ record }">
        <span>{{ record.remark}}</span>
      </template>
      <template #startTime="{ record }">
        <span>{{ formatDateTime(record.startTime) }} ({{ getDayOfWeek(record.startTime) }})</span>
      </template>
      <template #estimatedCost="{ record }">
        <span>{{ record.estimatedCost ? `¥${record.estimatedCost}` : '-' }}</span>
      </template>
      <template #status="{ record }">
        <GiCellTag :value="record.status" :dict="class_status" />
      </template>
      <template #action="{ record }">
        <a-space>
          <a-link v-permission="['education:lesson:get']" title="详情" @click="onDetail(record)">详情</a-link>
          <a-link v-permission="['education:lesson:update']" title="修改" @click="onUpdate(record)">修改</a-link>
          <a-link
            v-permission="['education:lesson:delete']"
            status="danger"
            :disabled="record.disabled"
            :title="record.disabled ? '不可删除' : '删除'"
            @click="onDelete(record)"
          >
            删除
          </a-link>
        </a-space>
      </template>
    </GiTable>

    <LessonAddModal ref="LessonAddModalRef" @save-success="search" />
    <LessonDetailDrawer ref="LessonDetailDrawerRef" />
  </div>
</template>

<script setup lang="ts">
import type { TableInstance } from '@arco-design/web-vue'
import LessonAddModal from './LessonAddModal.vue'
import LessonDetailDrawer from './LessonDetailDrawer.vue'
import { type LessonResp, type LessonQuery, deleteLesson, exportLesson, listLesson } from '@/apis/education/lesson'
import { useDownload, useTable } from '@/hooks'
import { useDict } from '@/hooks/app'
import { isMobile } from '@/utils'
import has from '@/utils/has'

defineOptions({ name: 'Lesson' })

const { yes_no,class_status } = useDict('yes_no','class_status')

// 格式化日期时间，去掉秒数
const formatDateTime = (dateTime: string) => {
  if (!dateTime) return ''
  // 如果是完整的日期时间格式，截取到分钟
  if (dateTime.includes(':')) {
    return dateTime.substring(0, 16) // 格式：2026-02-09 20:30
  }
  return dateTime
}

// 根据日期时间计算周几
const getDayOfWeek = (dateTime: string) => {
  if (!dateTime) return '-'
  
  const date = new Date(dateTime)
  if (isNaN(date.getTime())) return '-'
  
  const dayNames = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
  return dayNames[date.getDay()]
}

const queryForm = reactive<LessonQuery>({
  courseId: undefined,
  courseUid: undefined,
  name: undefined,
  agentCode: undefined,
  teacherUid: undefined,
  startTime: undefined,
  endTime: undefined,
  courseStatus: 'not_started',
  sort: ['id,desc']
})

const {
  tableData: dataList,
  loading,
  pagination,
  search,
  handleDelete
} = useTable((page) => listLesson({ ...queryForm, ...page }), { immediate: true })
const columns: TableInstance['columns'] = [
  { title: '课堂名称', dataIndex: 'name', slotName: 'name' },
  { title: '代理机构', dataIndex: 'agentCode', slotName: 'agentCode', width: 120, align: 'center' },
  { title: '开始时间', dataIndex: 'startTime', slotName: 'startTime' },
  { title: '上台人数', dataIndex: 'seatNum', slotName: 'seatNum' },
  { title: '是否录制', dataIndex: 'recordState', slotName: 'recordState' },
  { title: '备注', dataIndex: 'remark', slotName: 'remark', width: 200 },
  {
    title: '操作',
    dataIndex: 'action',
    slotName: 'action',
    width: 160,
    align: 'center',
    fixed: !isMobile() ? 'right' : undefined,
    show: has.hasPermOr(['education:lesson:get', 'education:lesson:update', 'education:lesson:delete'])
  }
]

// 重置
const reset = () => {
  queryForm.courseId = undefined
  queryForm.courseUid = undefined
  queryForm.name = undefined
  queryForm.agentCode = undefined
  queryForm.teacherUid = undefined
  queryForm.startTime = undefined
  queryForm.endTime = undefined
  search()
}

// 删除
const onDelete = (record: LessonResp) => {
  return handleDelete(() => deleteLesson(record.id), {
    content: `是否确定删除该条数据？`,
    showModal: true
  })
}

// 导出
const onExport = () => {
  useDownload(() => exportLesson(queryForm))
}

const LessonAddModalRef = ref<InstanceType<typeof LessonAddModal>>()
// 新增
const onAdd = () => {
  LessonAddModalRef.value?.onAdd()
}

// 修改
const onUpdate = (record: LessonResp) => {
  LessonAddModalRef.value?.onUpdate(record.id)
}

const LessonDetailDrawerRef = ref<InstanceType<typeof LessonDetailDrawer>>()
// 详情
const onDetail = (record: LessonResp) => {
  LessonDetailDrawerRef.value?.onOpen(record.id)
}
</script>

<style scoped lang="scss"></style>
